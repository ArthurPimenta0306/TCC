import gym
class FooExtraHardEnv(gym.Env):
    # nao sei oq poe aqui
    i = 0